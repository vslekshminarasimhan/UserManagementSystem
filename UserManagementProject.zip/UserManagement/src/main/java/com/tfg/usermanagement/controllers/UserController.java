package com.tfg.usermanagement.controllers;



import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.bcrypt.BCrypt;

import com.tfg.usermanagement.model.User;
import com.tfg.usermanagement.services.UserManagementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.security.SecureRandom;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping(value = "/api")
public class UserController {

	@Autowired
    private UserManagementService userMgmtService;

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);
	
	  @GetMapping(value = "/users/{id}")
	  @ResponseStatus(HttpStatus.OK) 
	  public Optional<User> getUserDetailsById(@PathVariable(value = "id") int id) { 
		  return userMgmtService.getUserDetailsById(id);
		  }
	 

	  @GetMapping("/users")
	    @ResponseStatus(HttpStatus.OK)
	    public List<User> getUserss() 
	    {
	    	return userMgmtService.getAllUsers();
	    }
	    
	    
	    @PostMapping(value = "/users")
	    @ResponseStatus(HttpStatus.CREATED)
	    public void createVehicle(@RequestBody User user){
	    	
	    	//String encyptedPassword = 	new BCryptPasswordEncoder(12, new SecureRandom()).encode(user.getPassword());
	    	//user.setPassword(encyptedPassword);
	    	
	    	  String pw_hash = BCrypt.hashpw(user.getPassword(), BCrypt.gensalt());
	    	    user.setPassword(pw_hash);
	    	 logger.info("Create User");
	    	 userMgmtService.createUser(user);
	    }

	    @PutMapping(value = "/users/{id}")
	    @ResponseStatus(HttpStatus.OK)
	    public void updateUser(@RequestBody User user, @PathVariable(value = "id") int id){
	    	userMgmtService.updateUser(user, id);
	    }

	    @DeleteMapping(value = "/users/{id}")
	    @ResponseStatus(HttpStatus.OK)
	    public void deleteUser(@PathVariable(value="id") int id)  {
	      	    	userMgmtService.deleteUserById(id);
	    }
	  
	  
	  
	    
	
	  @PostMapping("/users/login")
	  @ResponseStatus(HttpStatus.OK)
	  public String login(@RequestBody User loginDetails){
	  String loginMessage="";
		  User check = userMgmtService.findByName(loginDetails.getName());
		  
		 // if (check != null && BCrypt.checkpw(check.getPassword(), check.getPassword())) {
		  if (check != null && BCrypt.checkpw(loginDetails.getPassword(), check.getPassword())) {
		      loginMessage= "Login Succesful";
		  } else {
			  loginMessage = "Login Failure";
		  }
		  
	  
	   return loginMessage;
	  }
	 
	  
	  
   
}