package com.tfg.usermanagement.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.tfg.usermanagement.model.User;



@Repository
public interface UserRepository extends CrudRepository<User, Integer>{

	//User findByUserIdAndPassword(String name, String password);
	public User findByName(String name);
	
}
