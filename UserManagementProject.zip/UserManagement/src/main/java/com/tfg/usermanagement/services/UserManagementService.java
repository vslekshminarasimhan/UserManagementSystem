package com.tfg.usermanagement.services;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;

import com.tfg.usermanagement.exception.UserNotFoundException;
import com.tfg.usermanagement.model.User;

public interface UserManagementService {
	
	public Optional<User> getUserDetailsById(int id);
	 public List<User> getAllUsers();	
	 public void createUser(User user);
	 public void updateUser(User user, int id);
	 public void deleteUserById(int id);
	 
	// public User findByUserIdAndPassword(String userId, String password) throws UserNotFoundException; 	
	  public User findByName(String name);
	 
}
