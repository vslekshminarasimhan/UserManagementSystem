package com.tfg.usermanagement.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.tfg.usermanagement.exception.UserNotFoundException;
import com.tfg.usermanagement.model.User;
import com.tfg.usermanagement.repository.UserRepository;

@Service
public class UserManagementServiceImpl implements UserManagementService {

    @Autowired
    private UserRepository userRepository;
	
	@Override
	public Optional<User> getUserDetailsById(int id) {
		Optional<User> user = userRepository.findById(id);
	    
		return user;
	}

	
	   @Override
	   public List<User> getAllUsers() 
	    {
	    List<User> users = new ArrayList<User>();
	    userRepository.findAll().forEach(users1 -> users.add(users1));
	    return users;
	    }
	    

	    @Override
	    public void createUser(User user) {
	    	userRepository.save(user);
	    }

	    @Override
	    public void updateUser(User user, int id)   {
	    	userRepository.save(user);
	    }

	    @Override
	    public void deleteUserById(int id)  {
	    	userRepository.deleteById(id);
	    }
	
	   @Override
	   public User findByName(String name) {
		   return userRepository.findByName(name);
	   }
	    
	    
}
